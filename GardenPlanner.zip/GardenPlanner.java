
package gardenplanner;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


//class LayoutPlan extends JFrame{
//    JTextField t1,t2;
//    Label title,l1,l2;
//    Button b1;
//    public LayoutPlan(){
//        title=new Label("Specify your Layout Size");
//        title.setForeground(Color.BLUE);
//        l1=new Label("Width:");
//        l2=new Label("Height:");
//        t1=new JTextField();
//        t2=new JTextField();
//        setLocation(40,50);
//        setLayout(null);
//        setSize(300,280);
//        title.setBounds(100, 50, 100, 30);
//        add(title);
//        setVisible(true);
//    }
//}
public class GardenPlanner extends WindowAdapter implements ActionListener{
JFrame frame;
JFrame frame1;
Label title;
Button b1,b2;
GardenPlanner(){
    frame=new JFrame();
    title=new Label("Welcome to GreenThumb Company");
    frame.add(title);
    frame.setTitle("GreenThumb Garden Planner");
    frame.setSize(800,600);
   b1=new Button("Plan Layouts");
   b2=new Button("Select Plants");
   title.setBounds(220, 20, 200, 40);
   b1.setBounds(180, 80, 100, 40);
   b2.setBounds(360, 80, 100, 40);
   b1.setBackground(Color.cyan);
   b2.setBackground(Color.GREEN);
   
   frame.add(b1);
   frame.add(b2);
    frame.setLayout(null);
    frame.setAlwaysOnTop(true);
    frame.setVisible(true);
    
}
   
    public static void main(String[] args) {
       new GardenPlanner();
     
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1){
   frame1=new JFrame();
   frame1.setLayout(null);
   frame1.setVisible(true);
   
        }
    }
    
}
